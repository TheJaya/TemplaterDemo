﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Templater;
using NGS.Templater;
using System.IO;
using Newtonsoft.Json;

namespace Templater
{
    public class Program
    {
          var objDomain=new object();
            using (StreamReader r = new StreamReader("..\\..\\json1.json"))
            {
                string json = r.ReadToEnd();

                objDomain = JsonConvert.DeserializeObject<RootObject>(json);
            }
            
            var myFile = "template.docx";
            
            File.Copy(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + @"\docs\" + myFile, AppDomain.CurrentDomain.BaseDirectory + @"\\" + myFile, true);
            using (var document = Configuration.Factory.Open(AppDomain.CurrentDomain.BaseDirectory + @"\\" + myFile))
            {
                document.Process(objDomain);
              
            }
            Process.Start(AppDomain.CurrentDomain.BaseDirectory + @"\\" + myFile);
    
    }

  

    public class User
    {
        public string name { get; set; }
        public string age { get; set; }
    }

    public class Beer
    {
        public string name { get; set; }
        public string brewery { get; set; }
        public string type { get; set; }
        public double rating { get; set; }
        public double abv { get; set; }
    }

    public class RootObject
    {
        public User user { get; set; }
        public List<Beer> beers { get; set; }
    }

}
